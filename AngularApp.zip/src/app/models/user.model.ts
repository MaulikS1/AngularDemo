export interface User 
{
  email: string;
  userid: string;
}