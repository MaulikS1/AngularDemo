import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addnewuser',
  templateUrl: './addnewuser.component.html',
  styleUrls: ['./addnewuser.component.css']
})
export class AddnewuserComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
